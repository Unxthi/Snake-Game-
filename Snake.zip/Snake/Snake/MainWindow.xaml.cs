﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Snake
{
    public partial class MainWindow : Window
    {
        private readonly Dictionary<GridValue, ImageSource> GridValToImage = new()
        {
            { GridValue.empty, Images.empty },
            { GridValue.snake, Images.body },
            { GridValue.food, Images.food },
            { GridValue.outside, Images.deadBody }
        };
        private readonly Dictionary<Direction, int> DirToRotation = new()
        {
            { Direction.Up,0 },
            { Direction.Right, 90 },
            { Direction.Down, 180 },
            { Direction.Left, 270 }

        };
        private readonly int row = 15, col = 15;
        private readonly Image[,] gridImages;
        private GameState gameState;
        private bool gameRunning;

        public MainWindow()
        {
            InitializeComponent();
            gridImages = SetUpGrid();
            gameState = new GameState(row, col);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Keyboard.Focus(this); // Ensure the window receives keyboard input
        }

        private async void PreviewWindow_KeyDown(object sender, KeyEventArgs e)
        {
            // Prevent keys from passing through when overlay is up
            if (OverLay.Visibility == Visibility.Visible)
            {
                e.Handled = true;
            }

            // Start the game if not already running
            if (!gameRunning)
            {
                gameRunning = true;
                await RunGame();
                gameRunning = false;
            }
        }

        private async void Window_KeyDown(object sender, KeyEventArgs e)
        {
            // If the game hasn't started yet
            if (OverLay.Visibility == Visibility.Visible)
            {
                e.Handled = true;

                if (!gameRunning)
                {
                    gameRunning = true;
                    await RunGame();
                    gameRunning = false;
                }

                // Don't return — allow the key press to continue
            }

            if (gameState.GameOver)
                return;

            // Process movement keys
            switch (e.Key)
            {
                case Key.Left:
                    gameState.ChangeDirection(Direction.Left);
                    break;
                case Key.Right:
                    gameState.ChangeDirection(Direction.Right);
                    break;
                case Key.Up:
                    gameState.ChangeDirection(Direction.Up);
                    break;
                case Key.Down:
                    gameState.ChangeDirection(Direction.Down);
                    break;
            }
        }


        private async Task RunGame()
        {
            Draw();
            await ShowCountDown();
            OverLay.Visibility = Visibility.Hidden;
            await GameLoop();
            await ShowGameOver();
            gameState = new GameState(row, col); // Reset game state
        }

        private async Task GameLoop()
        {
            while (!gameState.GameOver)
            {
                await Task.Delay(100); // Control game speed
                gameState.Move();
                DrawGrid();
                ScoreText.Text = $"Score: {gameState.Score}";
            }

            MessageBox.Show($"Game Over! Your score is {gameState.Score}", "Snake", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private async Task ShowCountDown()
        {
            for (int i = 3; i > 0; i--)
            {
                OverLayText.Text = i.ToString();
                await Task.Delay(500);
            }
        }

        private Image[,] SetUpGrid()
        {
            Image[,] images = new Image[row, col];

            if (GameGrid == null)
            {
                MessageBox.Show("GameGrid is not defined in XAML or not accessible.");
                return images;
            }

            GameGrid.Rows = row;
            GameGrid.Columns = col;

            for (int r = 0; r < row; r++)
            {
                for (int c = 0; c < col; c++)
                {
                    Image image = new Image();
                    images[r, c] = image;
                    GameGrid.Children.Add(image);
                    RenderTransformOrigin = new Point(0.5, 0.5); // Set the origin for rotation
                }
            }

            return images;
        }

        public void Draw()
        {
            DrawGrid();
            DrawSnakeHead();
            ScoreText.Text = $"Score: {gameState.Score}";
        }

        public void DrawGrid()
        {
            for (int r = 0; r < row; r++)
            {
                for (int c = 0; c < col; c++)
                {
                    GridValue value = gameState.grid[r, c];
                    gridImages[r, c].Source = GridValToImage[value];
                    gridImages[r, c].RenderTransform = Transform.Identity; // Reset rotation
                }
            }
        }
        private void DrawSnakeHead()
        {
            Position headPos = gameState.HeadPosition(); // Get head position
            Image headImage = gridImages[headPos.row, headPos.col]; // Get corresponding image cell

            headImage.Source = Images.head; // Set head sprite

            int rotation = DirToRotation[gameState.Dir]; // Get rotation angle
            headImage.RenderTransform = new RotateTransform(rotation, 0.5, 0.5); // Centered rotation
        }

        private async Task ShowGameOver()
        {
            await Task.Delay(1000); // Delay before showing game over
            OverLay.Visibility = Visibility.Visible;
            OverLayText.Text = "PRESS ANY KEY TO START!";

        }
        }
    }
