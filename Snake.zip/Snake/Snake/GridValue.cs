﻿namespace Snake
{
    public enum GridValue
    {
        empty,
        snake,
        food,
        outside,
    }
}
